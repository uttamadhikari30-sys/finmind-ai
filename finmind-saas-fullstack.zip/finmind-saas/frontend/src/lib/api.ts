const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

function token() {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem('finmind_token') || '';
}

function headers() {
  return { 'Content-Type': 'application/json', Authorization: `Bearer ${token()}` };
}

export async function apiPost(path: string, body: Record<string, unknown>) {
  const r = await fetch(`${API}${path}`, { method: 'POST', headers: headers(), body: JSON.stringify(body) });
  if (!r.ok) { const e = await r.json(); throw new Error(e.error || 'API error'); }
  return r.json();
}

export async function apiGet(path: string) {
  const r = await fetch(`${API}${path}`, { headers: headers() });
  if (!r.ok) { const e = await r.json(); throw new Error(e.error || 'API error'); }
  return r.json();
}

export function saveAuth(token: string, user: Record<string, unknown>) {
  localStorage.setItem('finmind_token', token);
  localStorage.setItem('finmind_user', JSON.stringify(user));
}

export function getUser() {
  if (typeof window === 'undefined') return null;
  try { return JSON.parse(localStorage.getItem('finmind_user') || 'null'); } catch { return null; }
}

export function logout() {
  localStorage.removeItem('finmind_token');
  localStorage.removeItem('finmind_user');
}
