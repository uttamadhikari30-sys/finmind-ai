import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'FINMIND AI – Edme MIS Platform',
  description: 'Intelligent MIS & Finance Intelligence Platform',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
