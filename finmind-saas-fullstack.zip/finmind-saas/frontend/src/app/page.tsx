'use client';
import { useState, useEffect, useCallback } from 'react';
import { apiPost, apiGet, saveAuth, getUser, logout } from '@/lib/api';
import {
  LayoutDashboard, FileText, TrendingUp, Users, Calculator,
  Upload, Target, BarChart2, DollarSign, FileBarChart,
  LogOut, ChevronRight, Activity, AlertCircle, CheckCircle,
  Menu, X, Sparkles, ArrowUpRight, ArrowDownRight
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';

// ── Types ────────────────────────────────────────────────────────────────────
type User = { id: number; name: string; role: string; vertical?: string; email?: string };
type Page = 'dash' | 'pl' | 'le' | 'vert' | 'vpb' | 'bh' | 'aop' | 'maya';

const NAV: { id: Page; icon: React.ReactNode; label: string; roles: string[]; section: string }[] = [
  { id:'dash', icon:<LayoutDashboard size={15}/>, label:'Dashboard',          roles:['cfo','ceo','finance'], section:'OVERVIEW'   },
  { id:'pl',   icon:<FileText size={15}/>,         label:'P&L Statement',       roles:['cfo','ceo','finance'], section:'REPORTS'    },
  { id:'le',   icon:<TrendingUp size={15}/>,        label:'LE & Forecast',        roles:['cfo','ceo','finance'], section:'REPORTS'    },
  { id:'vert', icon:<Users size={15}/>,             label:'Vertical Performance', roles:['cfo','ceo','finance'], section:'ANALYTICS'  },
  { id:'vpb',  icon:<Calculator size={15}/>,        label:'VPB Calculator',       roles:['cfo','ceo','finance'], section:'ANALYTICS'  },
  { id:'bh',   icon:<BarChart2 size={15}/>,          label:'My Performance',       roles:['bh'],                  section:'MY VIEW'    },
  { id:'aop',  icon:<Target size={15}/>,             label:'Budget / AOP',         roles:['cfo','ceo','bh'],      section:'PLANNING'   },
  { id:'maya', icon:<Sparkles size={15}/>,           label:'MAYA AI',              roles:['cfo','ceo','finance','bh'], section:'AI' },
];

const INVITE_CODES: Record<string, { role: string; label: string }> = {
  'EDME-EXEC-2025': { role:'cfo',     label:'CFO Access'           },
  'EDME-CEO-2025':  { role:'ceo',     label:'CEO Access'           },
  'EDME-BH-2025':   { role:'bh',      label:'Business Head Access' },
  'EDME-FIN-2025':  { role:'finance', label:'Finance Access'       },
  'FINMIND-DEMO':   { role:'cfo',     label:'Demo Access'          },
};

// ── KPI Card ─────────────────────────────────────────────────────────────────
function KpiCard({ label, value, unit, change }: { label:string; value:number; unit:string; change:number }) {
  const up = change >= 0;
  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm border border-blue-50 hover:shadow-md transition-shadow">
      <p className="text-xs text-gray-400 uppercase tracking-wider mb-2">{label}</p>
      <p className="text-2xl font-bold text-navy font-mono">
        {unit === 'Cr' ? '₹' : ''}{value.toLocaleString()}{unit === '%' ? '%' : unit === 'Cr' ? ' Cr' : ''}
      </p>
      <p className={`text-xs mt-1 flex items-center gap-1 ${up ? 'text-green-500' : 'text-red-400'}`}>
        {up ? <ArrowUpRight size={12}/> : <ArrowDownRight size={12}/>}
        {up ? '+' : ''}{change}{unit === '%' ? ' pp' : unit === 'Cr' ? ' Cr' : ''} vs last period
      </p>
    </div>
  );
}

// ── Dashboard Page ────────────────────────────────────────────────────────────
function DashboardPage() {
  const [kpis, setKpis] = useState<Record<string, { value:number; unit:string; change:number; label:string }>>({});
  const [pl,   setPl]   = useState<{ months:string[]; revenue:number[]; net_profit:number[] } | null>(null);

  useEffect(() => {
    apiGet('/api/dashboard/kpis').then(setKpis).catch(() => {});
    apiGet('/api/reports/pl').then(setPl).catch(() => {});
  }, []);

  const chartData = pl ? pl.months.map((m,i) => ({
    month: m, Revenue: pl.revenue[i], Profit: pl.net_profit[i]
  })) : [];

  return (
    <div className="space-y-6 page-enter">
      <div>
        <h1 className="text-2xl font-bold text-navy font-serif">Company Dashboard</h1>
        <p className="text-xs text-gray-400 mt-1">FY 2025-26 · Live Data · Edme Insurance Brokers</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        {Object.entries(kpis).map(([k, v]) => <KpiCard key={k} {...v} />)}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-blue-50">
          <h3 className="font-semibold text-navy mb-4">Revenue Trend (₹ Cr)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#1C3687" stopOpacity={0.15}/>
                  <stop offset="95%" stopColor="#1C3687" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f3fb"/>
              <XAxis dataKey="month" tick={{ fontSize:11 }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fontSize:11 }} axisLine={false} tickLine={false}/>
              <Tooltip formatter={(v:number) => [`₹${v} Cr`]}/>
              <Area type="monotone" dataKey="Revenue" stroke="#1C3687" strokeWidth={2} fill="url(#rev)"/>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-sm border border-blue-50">
          <h3 className="font-semibold text-navy mb-4">Net Profit (₹ Cr)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f3fb"/>
              <XAxis dataKey="month" tick={{ fontSize:11 }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fontSize:11 }} axisLine={false} tickLine={false}/>
              <Tooltip formatter={(v:number) => [`₹${v} Cr`]}/>
              <Bar dataKey="Profit" fill="#00a878" radius={[4,4,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

// ── P&L Page ──────────────────────────────────────────────────────────────────
function PLPage() {
  const [data, setData] = useState<{ months:string[]; revenue:number[]; commission:number[]; expenses:number[]; net_profit:number[] } | null>(null);
  useEffect(() => { apiGet('/api/reports/pl').then(setData).catch(()=>{}); }, []);

  if (!data) return <Loader/>;
  const rows = [
    { label:'Gross Premium Income', values: data.revenue,    cls:'font-semibold text-navy' },
    { label:'Net Commission',        values: data.commission, cls:'text-green-600' },
    { label:'Operating Expenses',    values: data.expenses,   cls:'text-red-500' },
    { label:'Net Profit',            values: data.net_profit, cls:'font-bold text-navy' },
  ];
  const ytd = (arr: number[]) => arr.reduce((a,b) => a+b, 0).toFixed(2);

  return (
    <div className="page-enter">
      <h1 className="text-2xl font-bold text-navy font-serif mb-1">P&L Statement</h1>
      <p className="text-xs text-gray-400 mb-6">FY 2025-26 · All figures in ₹ Cr</p>
      <div className="bg-white rounded-2xl shadow-sm border border-blue-50 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-blue-50">
              <th className="text-left py-4 px-5 text-xs text-gray-400 uppercase tracking-wider w-48">Metric</th>
              {data.months.map(m => <th key={m} className="text-right py-4 px-3 text-xs text-gray-400 font-medium">{m}</th>)}
              <th className="text-right py-4 px-5 text-xs text-navy font-bold">YTD</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={i} className={`border-b border-blue-50 hover:bg-blue-50/30 ${i===3?'bg-navy/5':''}`}>
                <td className={`py-3 px-5 ${row.cls}`}>{row.label}</td>
                {row.values.map((v,j) => <td key={j} className={`text-right py-3 px-3 ${row.cls}`}>{v.toFixed(2)}</td>)}
                <td className={`text-right py-3 px-5 font-bold ${row.cls}`}>{ytd(row.values)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── LE / Forecast Page ────────────────────────────────────────────────────────
function LEPage() {
  const [data, setData] = useState<{ aop_target:number; le_current:number; achievement:number; variance:number; months:string[]; actual:(number|null)[]; forecast:(number|null)[]; aop:number[] } | null>(null);
  useEffect(() => { apiGet('/api/reports/forecast').then(setData).catch(()=>{}); }, []);
  if (!data) return <Loader/>;

  const chartData = data.months.map((m,i) => ({
    month:m,
    Actual:   data.actual[i],
    Forecast: data.forecast[i],
    AOP:      data.aop[i],
  }));

  return (
    <div className="page-enter space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-navy font-serif">LE & Forecasting</h1>
        <p className="text-xs text-gray-400 mt-1">Latest Estimate vs AOP · FY 2025-26</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label:'AOP Target',   val:`₹${data.aop_target} Cr`,  cls:'text-navy' },
          { label:'LE Current',   val:`₹${data.le_current} Cr`,  cls:'text-green-600' },
          { label:'Achievement',  val:`${data.achievement}%`,     cls:'text-blue-600' },
          { label:'Variance',     val:`₹${data.variance} Cr`,    cls:'text-red-500' },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-2xl p-5 shadow-sm border border-blue-50 text-center">
            <p className="text-xs text-gray-400 uppercase tracking-wider mb-2">{c.label}</p>
            <p className={`text-xl font-bold font-mono ${c.cls}`}>{c.val}</p>
          </div>
        ))}
      </div>
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-blue-50">
        <h3 className="font-semibold text-navy mb-4">Revenue: Actual vs Forecast vs AOP (₹ Cr)</h3>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f3fb"/>
            <XAxis dataKey="month" tick={{ fontSize:11 }} axisLine={false} tickLine={false}/>
            <YAxis tick={{ fontSize:11 }} axisLine={false} tickLine={false}/>
            <Tooltip formatter={(v:number) => v ? [`₹${v} Cr`] : ['-']}/>
            <Legend/>
            <Line type="monotone" dataKey="Actual"   stroke="#1C3687" strokeWidth={2} dot={{ r:4 }} connectNulls={false}/>
            <Line type="monotone" dataKey="Forecast"  stroke="#00a878" strokeWidth={2} strokeDasharray="6 3" dot={{ r:4 }} connectNulls={false}/>
            <Line type="monotone" dataKey="AOP"       stroke="#C8952A" strokeWidth={1.5} strokeDasharray="3 3"/>
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ── Vertical Performance ──────────────────────────────────────────────────────
function VertPage() {
  const [rows, setRows] = useState<{ id:string; name:string; segment:string; revenue:number; target:number; achievement:number; clients:number }[]>([]);
  useEffect(() => { apiGet('/api/reports/verticals').then(setRows).catch(()=>{}); }, []);

  return (
    <div className="page-enter">
      <h1 className="text-2xl font-bold text-navy font-serif mb-1">Vertical Performance</h1>
      <p className="text-xs text-gray-400 mb-6">All Business Heads · FY 2025-26</p>
      <div className="bg-white rounded-2xl shadow-sm border border-blue-50 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-blue-50">
              {['Business Head','Segment','Revenue (Cr)','Target (Cr)','Achievement','Clients'].map(h => (
                <th key={h} className="text-left py-3 px-5 text-xs text-gray-400 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id} className="border-b border-blue-50 hover:bg-blue-50/30">
                <td className="py-3 px-5 font-semibold text-navy">{r.name}</td>
                <td className="py-3 px-5"><span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded-full text-xs">{r.segment}</span></td>
                <td className="py-3 px-5 font-mono">₹{r.revenue}</td>
                <td className="py-3 px-5 font-mono text-gray-400">₹{r.target}</td>
                <td className="py-3 px-5">
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-1.5 bg-blue-50 rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width:`${Math.min(r.achievement,100)}%`, background: r.achievement>=100?'#00a878':'#1C3687' }}/>
                    </div>
                    <span className={`text-xs font-bold ${r.achievement>=100?'text-green-600':'text-navy'}`}>{r.achievement}%</span>
                  </div>
                </td>
                <td className="py-3 px-5 font-mono">{r.clients}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── VPB Calculator ────────────────────────────────────────────────────────────
function VPBPage() {
  const [form, setForm] = useState({ revenue:'', target:'', collections:'', net_commission:'' });
  const [result, setResult] = useState<{ achievement:string; vpb_pct:number; vpb_amount:string } | null>(null);
  const [loading, setLoading] = useState(false);

  const calc = async () => {
    setLoading(true);
    try {
      const r = await apiPost('/api/analytics/vpb', {
        revenue: +form.revenue, target: +form.target,
        collections: +form.collections, net_commission: +form.net_commission
      });
      setResult(r);
    } catch {}
    setLoading(false);
  };

  return (
    <div className="page-enter max-w-2xl">
      <h1 className="text-2xl font-bold text-navy font-serif mb-1">VPB Calculator</h1>
      <p className="text-xs text-gray-400 mb-6">Variable Pay (VPB) Eligibility Calculator</p>
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-blue-50 space-y-4">
        {[
          { key:'revenue',        label:'Actual Revenue (₹ Cr)',    ph:'e.g. 8.4' },
          { key:'target',         label:'AOP Target (₹ Cr)',         ph:'e.g. 9.0' },
          { key:'collections',    label:'Collections (₹ Cr)',        ph:'e.g. 7.8' },
          { key:'net_commission', label:'Net Commission (₹ Cr)',     ph:'e.g. 1.2' },
        ].map(f => (
          <div key={f.key}>
            <label className="text-xs text-gray-500 uppercase tracking-wider mb-1 block">{f.label}</label>
            <input
              type="number" placeholder={f.ph}
              value={form[f.key as keyof typeof form]}
              onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
              className="w-full border border-blue-100 rounded-xl px-4 py-2.5 text-sm font-mono focus:outline-none focus:border-navy"
            />
          </div>
        ))}
        <button onClick={calc} disabled={loading}
          className="w-full bg-navy text-white py-3 rounded-xl font-semibold text-sm hover:bg-navy2 transition-colors disabled:opacity-60">
          {loading ? 'Calculating…' : 'Calculate VPB'}
        </button>
        {result && (
          <div className="mt-4 p-5 bg-navy/5 rounded-xl space-y-2 border border-navy/10">
            <p className="text-xs text-gray-400 uppercase tracking-wider font-semibold">Result</p>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div><p className="text-xs text-gray-400">Achievement</p><p className="text-xl font-bold text-navy font-mono">{result.achievement}%</p></div>
              <div><p className="text-xs text-gray-400">VPB %</p><p className="text-xl font-bold text-green-600 font-mono">{result.vpb_pct}%</p></div>
              <div><p className="text-xs text-gray-400">VPB Amount</p><p className="text-xl font-bold text-gold font-mono">₹{result.vpb_amount} Cr</p></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── BH Performance ────────────────────────────────────────────────────────────
function BHPage({ user }: { user: User }) {
  const [data, setData] = useState<{ name:string; revenue:number; target:number; ytd:number; pipeline:number; clients:number; renewal_rate:number } | null>(null);
  useEffect(() => { apiGet('/api/bh/performance').then(setData).catch(()=>{}); }, []);
  if (!data) return <Loader/>;

  const ach = ((data.revenue / data.target) * 100).toFixed(1);
  return (
    <div className="page-enter space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-navy font-serif">My Performance</h1>
        <p className="text-xs text-gray-400 mt-1">{user.name} · FY 2025-26</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {[
          { label:'Monthly Revenue',  val:`₹${data.revenue} Cr`,   cls:'text-navy'       },
          { label:'AOP Target',       val:`₹${data.target} Cr`,    cls:'text-gray-500'   },
          { label:'Achievement',      val:`${ach}%`,                cls:'text-green-600'  },
          { label:'YTD Revenue',      val:`₹${data.ytd} Cr`,       cls:'text-navy'       },
          { label:'Pipeline',         val:`₹${data.pipeline} Cr`,  cls:'text-purple-600' },
          { label:'Active Clients',   val:`${data.clients}`,        cls:'text-teal-600'   },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-2xl p-5 shadow-sm border border-blue-50">
            <p className="text-xs text-gray-400 uppercase tracking-wider mb-2">{c.label}</p>
            <p className={`text-xl font-bold font-mono ${c.cls}`}>{c.val}</p>
          </div>
        ))}
      </div>
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-blue-50">
        <h3 className="font-semibold text-navy mb-3">Achievement vs Target</h3>
        <div className="flex items-center gap-4">
          <div className="flex-1 h-4 bg-blue-50 rounded-full overflow-hidden">
            <div className="h-full bg-navy rounded-full transition-all duration-700" style={{ width:`${Math.min(+ach,100)}%` }}/>
          </div>
          <span className="font-bold text-navy font-mono text-lg">{ach}%</span>
        </div>
        <div className="flex justify-between text-xs text-gray-400 mt-2">
          <span>₹0</span><span>₹{(data.target/2).toFixed(1)} Cr</span><span>₹{data.target} Cr</span>
        </div>
      </div>
    </div>
  );
}

// ── AOP Page ──────────────────────────────────────────────────────────────────
function AOPPage() {
  const [data, setData] = useState<{ fy:string; total_aop:number; q1:number; q2:number; q3:number; q4:number; verticals:{ name:string; aop:number; le:number; variance:number }[] } | null>(null);
  useEffect(() => { apiGet('/api/planning/aop').then(setData).catch(()=>{}); }, []);
  if (!data) return <Loader/>;
  return (
    <div className="page-enter space-y-6">
      <div><h1 className="text-2xl font-bold text-navy font-serif">Budget / AOP</h1><p className="text-xs text-gray-400 mt-1">FY {data.fy} · Annual Operating Plan</p></div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { label:'Total AOP', val:`₹${data.total_aop} Cr` },
          { label:'Q1 Target', val:`₹${data.q1} Cr` },
          { label:'Q2 Target', val:`₹${data.q2} Cr` },
          { label:'Q3 Target', val:`₹${data.q3} Cr` },
          { label:'Q4 Target', val:`₹${data.q4} Cr` },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-2xl p-4 shadow-sm border border-blue-50 text-center">
            <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">{c.label}</p>
            <p className="text-lg font-bold font-mono text-navy">{c.val}</p>
          </div>
        ))}
      </div>
      <div className="bg-white rounded-2xl shadow-sm border border-blue-50 overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-blue-50">
            {['Vertical','AOP (Cr)','LE (Cr)','Variance'].map(h=><th key={h} className="text-left py-3 px-5 text-xs text-gray-400 uppercase tracking-wider">{h}</th>)}
          </tr></thead>
          <tbody>
            {data.verticals.map(v=>(
              <tr key={v.name} className="border-b border-blue-50 hover:bg-blue-50/30">
                <td className="py-3 px-5 font-semibold text-navy">{v.name}</td>
                <td className="py-3 px-5 font-mono">₹{v.aop}</td>
                <td className="py-3 px-5 font-mono text-green-600">₹{v.le}</td>
                <td className="py-3 px-5 font-mono text-red-500">₹{v.variance}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── MAYA AI ───────────────────────────────────────────────────────────────────
function MayaPage() {
  const [msgs, setMsgs] = useState<{ role:'user'|'maya'; text:string }[]>([
    { role:'maya', text:'🙏 Namaste! I\'m MAYA, your AI financial intelligence assistant. Ask me about revenue, forecasts, VPB, verticals, or market insights.' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const send = async () => {
    if (!input.trim()) return;
    const q = input.trim();
    setInput('');
    setMsgs(m => [...m, { role:'user', text:q }]);
    setLoading(true);
    try {
      const r = await apiPost('/api/ai/maya', { message: q });
      setMsgs(m => [...m, { role:'maya', text: r.response }]);
    } catch {
      setMsgs(m => [...m, { role:'maya', text:'Sorry, I couldn\'t process that. Please try again.' }]);
    }
    setLoading(false);
  };

  return (
    <div className="page-enter flex flex-col h-[calc(100vh-130px)]">
      <div><h1 className="text-2xl font-bold text-navy font-serif mb-1">MAYA AI</h1><p className="text-xs text-gray-400 mb-4">Your intelligent financial analysis assistant</p></div>
      <div className="flex-1 overflow-y-auto bg-white rounded-2xl p-5 shadow-sm border border-blue-50 space-y-4 mb-4">
        {msgs.map((m,i) => (
          <div key={i} className={`flex ${m.role==='user'?'justify-end':''}`}>
            <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm ${m.role==='user'?'bg-navy text-white':'bg-blue-50 text-gray-700'}`}>
              {m.text}
            </div>
          </div>
        ))}
        {loading && <div className="flex"><div className="bg-blue-50 px-4 py-3 rounded-2xl text-sm text-gray-400">MAYA is thinking…</div></div>}
      </div>
      <div className="flex gap-3">
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()}
          placeholder="Ask MAYA anything… (revenue, forecast, VPB…)"
          className="flex-1 border border-blue-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-navy"/>
        <button onClick={send} disabled={loading}
          className="bg-navy text-white px-6 rounded-xl font-semibold text-sm hover:bg-navy2 transition-colors disabled:opacity-50">
          Send
        </button>
      </div>
    </div>
  );
}

// ── Loader ────────────────────────────────────────────────────────────────────
function Loader() {
  return <div className="flex items-center justify-center h-48"><div className="w-8 h-8 border-2 border-navy border-t-transparent rounded-full animate-spin"/></div>;
}

// ── Invite Gate ───────────────────────────────────────────────────────────────
function InviteGate({ onValid }: { onValid: (role: string) => void }) {
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [ok, setOk] = useState(false);

  const validate = () => {
    const entry = INVITE_CODES[code.trim().toUpperCase()];
    if (entry) { setOk(true); setErr(''); setTimeout(() => onValid(entry.role), 600); }
    else { setErr('Invalid invite code. Contact your administrator.'); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background:'linear-gradient(135deg,#050d24 0%,#0c1e50 55%,#0e2260 100%)' }}>
      <div className="w-full max-w-md bg-white/5 border border-white/10 rounded-3xl p-10 text-center shadow-2xl backdrop-blur-xl">
        <div className="text-4xl mb-3">🔐</div>
        <h1 className="text-2xl font-bold text-white font-serif mb-1">FINMIND AI</h1>
        <p className="text-xs text-white/40 uppercase tracking-widest mb-8">Edme Insurance · Private Access</p>
        <div className="text-left mb-2 text-xs text-white/40 uppercase tracking-wider font-semibold">Invite Code</div>
        <input
          value={code} onChange={e => setCode(e.target.value.toUpperCase())}
          onKeyDown={e => e.key === 'Enter' && validate()}
          placeholder="EDME-XXXX-2025"
          className="w-full bg-white/8 border border-white/15 rounded-xl px-4 py-3 text-white text-center font-mono tracking-widest text-base mb-2 focus:outline-none focus:border-white/40 placeholder-white/25"
          style={{ background:'rgba(255,255,255,0.06)' }}
        />
        {err && <p className="text-red-400 text-xs mb-3">{err}</p>}
        {ok  && <p className="text-green-400 text-xs mb-3">✅ Valid! Loading…</p>}
        {!ok && !err && <div className="mb-3"/>}
        <button onClick={validate}
          className="w-full bg-navy text-white py-3 rounded-xl font-semibold text-sm hover:bg-navy3 transition-colors mb-6">
          Continue →
        </button>
        <p className="text-xs text-white/20">🔒 256-bit SSL · Invite-only · Confidential</p>
        <div className="mt-4 text-xs text-white/20 space-y-1">
          <p>Demo codes: <span className="font-mono text-white/40">FINMIND-DEMO</span> · <span className="font-mono text-white/40">EDME-EXEC-2025</span></p>
        </div>
      </div>
    </div>
  );
}

// ── Login ─────────────────────────────────────────────────────────────────────
function LoginPage({ inviteRole, onLogin }: { inviteRole: string; onLogin: (u: User, t: string) => void }) {
  const [name, setName] = useState('');
  const [vertical, setVertical] = useState('v_anurag');
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  const VERTICALS = [
    { id:'v_anurag',name:'Anurag Mishra — Corporate'},{ id:'v_asheesh',name:'Asheesh Handa — SME'},
    { id:'v_jigar', name:'Jigar Parikh — Corporate'},  { id:'v_neha',   name:'Neha Yadav — Health'},
    { id:'v_nikhil',name:'Nikhil Mhatre — Retail'},    { id:'v_saurabh',name:'Saurabh Sharma — Corporate'},
    { id:'v_kanishka',name:'Kanishka Gadi — Retail'},  { id:'v_kunal',  name:'Kunal Khanna — Corporate'},
    { id:'v_mohan', name:'Mohan Agarwal — SME'},        { id:'v_nitin',  name:'Nitin Firke — Marine'},
    { id:'v_rajkumar',name:'Rajkumar ABG — Corporate'},{ id:'v_rushik', name:'Rushik Patel — SME'},
    { id:'v_saurav',name:'Saurav Maulik — Health'},    { id:'v_sonal',  name:'Sonal Gulati — Retail'},
    { id:'v_vishwajeet',name:'Vishwajeet Kadam — Marine'},
  ];

  const ROLE_DEFAULTS: Record<string, string> = {
    cfo:'Praveen Ladia', ceo:'Sanjay Radhakrishnan', finance:'Finance Team', bh:''
  };

  const login = async () => {
    setLoading(true); setErr('');
    try {
      const codes: Record<string, string> = {
        cfo:'EDME-EXEC-2025', ceo:'EDME-CEO-2025', finance:'EDME-FIN-2025', bh:'EDME-BH-2025'
      };
      const r = await apiPost('/api/auth/invite-login', {
        inviteCode: codes[inviteRole] || 'FINMIND-DEMO',
        name: name || ROLE_DEFAULTS[inviteRole] || 'User',
        vertical: inviteRole === 'bh' ? vertical : null,
      });
      saveAuth(r.token, r.user);
      onLogin(r.user, r.token);
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : 'Login failed');
    }
    setLoading(false);
  };

  const roleLabel: Record<string, string> = { cfo:'CFO', ceo:'CEO', finance:'Finance Team', bh:'Business Head' };

  return (
    <div className="min-h-screen flex" style={{ background:'linear-gradient(135deg,#050d24 0%,#0c1e50 55%,#0e2260 100%)' }}>
      {/* Brand panel */}
      <div className="hidden lg:flex flex-col justify-center px-16 w-1/2 text-white">
        <div className="text-5xl font-bold font-serif mb-4">FINMIND AI</div>
        <div className="text-white/40 text-xs uppercase tracking-widest mb-8">Edme Insurance Brokers Limited</div>
        <div className="text-white/60 text-sm leading-7 max-w-xs">
          Enterprise-grade financial intelligence — real-time P&L, LE analytics, VPB calculator, vertical performance, and AI-powered insights.
        </div>
        <div className="flex gap-3 mt-8 flex-wrap">
          {['FY 2025-26','v12.0','15 Verticals','Role-based Access'].map(t => (
            <span key={t} className="px-3 py-1 bg-white/10 rounded-full text-xs text-white/60">{t}</span>
          ))}
        </div>
      </div>
      {/* Form */}
      <div className="flex-1 flex items-center justify-center px-6">
        <div className="w-full max-w-sm bg-white rounded-3xl p-8 shadow-2xl">
          <h2 className="text-xl font-bold text-navy font-serif mb-1">Welcome Back</h2>
          <p className="text-xs text-gray-400 mb-6">Signing in as <span className="text-navy font-semibold">{roleLabel[inviteRole] || 'User'}</span></p>
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-400 uppercase tracking-wider mb-1 block">Full Name</label>
              <input value={name} onChange={e=>setName(e.target.value)} placeholder={ROLE_DEFAULTS[inviteRole]||'Your full name'}
                className="w-full border border-blue-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-navy"/>
            </div>
            {inviteRole === 'bh' && (
              <div>
                <label className="text-xs text-gray-400 uppercase tracking-wider mb-1 block">Your Vertical</label>
                <select value={vertical} onChange={e=>setVertical(e.target.value)}
                  className="w-full border border-blue-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-navy">
                  {VERTICALS.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
                </select>
              </div>
            )}
            {err && <p className="text-red-500 text-xs">{err}</p>}
            <button onClick={login} disabled={loading}
              className="w-full bg-navy text-white py-3 rounded-xl font-semibold text-sm hover:bg-navy2 transition-colors disabled:opacity-60">
              {loading ? 'Signing in…' : `Sign in to FINMIND AI →`}
            </button>
          </div>
          <p className="text-xs text-gray-300 text-center mt-6">🔐 256-bit SSL · Edme Insurance · Confidential</p>
        </div>
      </div>
    </div>
  );
}

// ── Main App Shell ────────────────────────────────────────────────────────────
function AppShell({ user, onLogout }: { user: User; onLogout: () => void }) {
  const [page, setPage] = useState<Page>('dash');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const nav = NAV.filter(n => n.roles.includes(user.role));
  const defaultPage = user.role === 'bh' ? 'bh' : 'dash';
  useEffect(() => { setPage(defaultPage as Page); }, [defaultPage]);

  const pages: Record<Page, React.ReactNode> = {
    dash:  <DashboardPage/>,
    pl:    <PLPage/>,
    le:    <LEPage/>,
    vert:  <VertPage/>,
    vpb:   <VPBPage/>,
    bh:    <BHPage user={user}/>,
    aop:   <AOPPage/>,
    maya:  <MayaPage/>,
  };

  const initials = user.name.split(' ').map((n:string)=>n[0]).join('').toUpperCase().slice(0,2);
  const roleLabel: Record<string, string> = { cfo:'CFO',ceo:'CEO',finance:'Finance Team',bh:'Business Head' };

  // Group nav by section
  const sections = Array.from(new Set(nav.map(n=>n.section)));

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 transition-all duration-300 ${sidebarOpen ? 'w-64' : 'w-0 overflow-hidden'}`}
        style={{ background:'linear-gradient(180deg,#050d24 0%,#0c1e50 55%,#0e2260 100%)', boxShadow:'4px 0 28px rgba(0,0,0,0.28)' }}>
        {/* Logo */}
        <div className="px-5 py-4 border-b border-white/6">
          <div className="text-white font-bold text-lg font-serif">FINMIND AI</div>
          <div className="text-white/28 text-[9px] uppercase tracking-widest">Edme MIS Platform · v12</div>
        </div>
        {/* User */}
        <div className="px-4 py-3 border-b border-white/6 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-red to-red2 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">{initials}</div>
          <div className="min-w-0">
            <div className="text-white text-xs font-semibold truncate">{user.name}</div>
            <div className="text-white/38 text-[9px] bg-white/8 px-2 py-0.5 rounded-full inline-block mt-0.5">{roleLabel[user.role]||user.role}</div>
          </div>
        </div>
        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-2 px-0" style={{ maxHeight:'calc(100vh - 200px)' }}>
          {sections.map(sec => (
            <div key={sec}>
              <div className="px-4 pt-3 pb-1 text-[9px] uppercase tracking-widest text-white/22 font-bold">{sec}</div>
              {nav.filter(n=>n.section===sec).map(n => (
                <button key={n.id} onClick={() => setPage(n.id)}
                  className={`w-full flex items-center gap-2.5 px-4 py-2 mx-1.5 rounded-lg text-xs font-medium transition-all relative ${page===n.id?'bg-white/10 text-white':'text-white/52 hover:bg-white/7 hover:text-white/88'}`}
                  style={{ width:'calc(100% - 12px)' }}>
                  {page===n.id && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-red rounded-r" style={{ left:'-7px' }}/>}
                  {n.icon}<span>{n.label}</span>
                </button>
              ))}
            </div>
          ))}
        </nav>
        {/* Logout */}
        <div className="px-4 py-3 border-t border-white/6">
          <button onClick={onLogout} className="w-full flex items-center gap-2 text-white/40 hover:text-white/80 text-xs py-2 transition-colors">
            <LogOut size={13}/> Sign out
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className={`flex-1 flex flex-col transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-0'}`}>
        {/* Header */}
        <header className="fixed right-0 top-0 z-40 h-[66px] bg-white/97 border-b border-blue-50 flex items-center px-5 gap-3 shadow-sm"
          style={{ left: sidebarOpen ? '256px' : '0', backdropFilter:'blur(16px)' }}>
          <button onClick={() => setSidebarOpen(s=>!s)} className="text-gray-400 hover:text-navy transition-colors">
            {sidebarOpen ? <X size={18}/> : <Menu size={18}/>}
          </button>
          <div>
            <div className="text-base font-bold text-navy font-serif leading-tight">{NAV.find(n=>n.id===page)?.label || 'Dashboard'}</div>
            <div className="text-[10px] text-gray-400">Edme Insurance Brokers · FY 2025-26</div>
          </div>
          <div className="flex-1"/>
          <button onClick={()=>setPage('maya')} className="flex items-center gap-2 px-3 py-1.5 rounded-full text-white text-xs font-semibold cursor-pointer"
            style={{ background:'linear-gradient(135deg,#1C3687,#2a4cc0)', boxShadow:'0 3px 12px rgba(28,54,135,0.28)' }}>
            <span className="w-1.5 h-1.5 rounded-full bg-green animate-blink"/>MAYA AI
          </button>
        </header>
        {/* Page content */}
        <main className="flex-1 overflow-y-auto pt-[66px] px-6 py-6" style={{ background:'#f0f3fb' }}>
          {pages[page]}
        </main>
      </div>
    </div>
  );
}

// ── Root ──────────────────────────────────────────────────────────────────────
export default function Home() {
  const [stage, setStage] = useState<'invite'|'login'|'app'>('invite');
  const [inviteRole, setInviteRole] = useState('');
  const [user, setUser] = useState<User | null>(null);

  // Check existing session
  useEffect(() => {
    const u = getUser();
    if (u) { setUser(u); setStage('app'); }
  }, []);

  const handleLogout = useCallback(() => {
    logout(); setUser(null); setStage('invite');
  }, []);

  if (stage === 'invite') return <InviteGate onValid={r => { setInviteRole(r); setStage('login'); }}/>;
  if (stage === 'login')  return <LoginPage inviteRole={inviteRole} onLogin={(u,_t) => { setUser(u); setStage('app'); }}/>;
  if (stage === 'app' && user) return <AppShell user={user} onLogout={handleLogout}/>;
  return null;
}
